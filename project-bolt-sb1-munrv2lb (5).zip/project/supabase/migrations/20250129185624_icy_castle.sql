/*
  # Criar tabela de obras

  1. Nova Tabela
    - `obras`
      - `id` (uuid, chave primária)
      - `nome` (texto, não nulo)
      - `valor` (decimal, não nulo)
      - `origem_recursos` (texto, não nulo)
      - `numero_contrato` (texto, não nulo)
      - `numero_processo_licitatorio` (texto, não nulo)
      - `prazo_execucao` (timestamp com timezone, não nulo)
      - `prazo_vigencia_contrato` (timestamp com timezone, não nulo)
      - `porcentagem_conclusao` (inteiro, não nulo, padrão 0)
      - `data_criacao` (timestamp com timezone, não nulo, padrão now())
      - `data_atualizacao` (timestamp com timezone, não nulo, padrão now())
      - `user_id` (uuid, não nulo, referência ao auth.users)

  2. Segurança
    - Habilitar RLS na tabela `obras`
    - Adicionar políticas para usuários autenticados:
      - Leitura: apenas suas próprias obras
      - Inserção: apenas com user_id correspondente
      - Atualização: apenas suas próprias obras
*/

CREATE TABLE IF NOT EXISTS obras (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  nome text NOT NULL,
  valor decimal NOT NULL,
  origem_recursos text NOT NULL,
  numero_contrato text NOT NULL,
  numero_processo_licitatorio text NOT NULL,
  prazo_execucao timestamptz NOT NULL,
  prazo_vigencia_contrato timestamptz NOT NULL,
  porcentagem_conclusao integer NOT NULL DEFAULT 0,
  data_criacao timestamptz NOT NULL DEFAULT now(),
  data_atualizacao timestamptz NOT NULL DEFAULT now(),
  user_id uuid NOT NULL REFERENCES auth.users(id)
);

ALTER TABLE obras ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Usuários podem ler suas próprias obras"
  ON obras
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Usuários podem inserir suas próprias obras"
  ON obras
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Usuários podem atualizar suas próprias obras"
  ON obras
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id);