import React, { useState } from 'react';
import { Obra } from '../types/types';

interface ObraFormProps {
  onSubmit: (obra: Omit<Obra, 'id' | 'dataCriacao' | 'dataAtualizacao'>) => void;
}

export function ObraForm({ onSubmit }: ObraFormProps) {
  const [formData, setFormData] = useState({
    nome: '',
    valor: 0,
    origemRecursos: '',
    numeroContrato: '',
    numeroProcessoLicitatorio: '',
    prazoExecucao: '',
    prazoVigenciaContrato: '',
    porcentagemConclusao: 0
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit({
      ...formData,
      prazoExecucao: new Date(formData.prazoExecucao),
      prazoVigenciaContrato: new Date(formData.prazoVigenciaContrato)
    });
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4 bg-white p-6 rounded-lg shadow">
      <div>
        <label className="block text-sm font-medium text-gray-700">Nome da Obra</label>
        <input
          type="text"
          required
          className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
          value={formData.nome}
          onChange={(e) => setFormData({ ...formData, nome: e.target.value })}
        />
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700">Valor (R$)</label>
        <input
          type="number"
          required
          min="0"
          step="0.01"
          className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
          value={formData.valor}
          onChange={(e) => setFormData({ ...formData, valor: parseFloat(e.target.value) })}
        />
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700">Origem dos Recursos</label>
        <input
          type="text"
          required
          className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
          value={formData.origemRecursos}
          onChange={(e) => setFormData({ ...formData, origemRecursos: e.target.value })}
        />
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700">Número do Contrato</label>
        <input
          type="text"
          required
          className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
          value={formData.numeroContrato}
          onChange={(e) => setFormData({ ...formData, numeroContrato: e.target.value })}
        />
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700">Número do Processo Licitatório</label>
        <input
          type="text"
          required
          className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
          value={formData.numeroProcessoLicitatorio}
          onChange={(e) => setFormData({ ...formData, numeroProcessoLicitatorio: e.target.value })}
        />
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700">Prazo de Execução</label>
        <input
          type="date"
          required
          className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
          value={formData.prazoExecucao}
          onChange={(e) => setFormData({ ...formData, prazoExecucao: e.target.value })}
        />
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700">Prazo de Vigência do Contrato</label>
        <input
          type="date"
          required
          className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
          value={formData.prazoVigenciaContrato}
          onChange={(e) => setFormData({ ...formData, prazoVigenciaContrato: e.target.value })}
        />
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700">Porcentagem de Conclusão</label>
        <input
          type="number"
          required
          min="0"
          max="100"
          className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
          value={formData.porcentagemConclusao}
          onChange={(e) => setFormData({ ...formData, porcentagemConclusao: parseInt(e.target.value) })}
        />
      </div>

      <button
        type="submit"
        className="w-full bg-blue-600 text-white py-2 px-4 rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2"
      >
        Cadastrar Obra
      </button>
    </form>
  );
}