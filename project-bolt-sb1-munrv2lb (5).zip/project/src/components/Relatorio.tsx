import React from 'react';
import { Obra, RelatorioTipo } from '../types/types';

interface RelatorioProps {
  obras: Obra[];
  tipo: RelatorioTipo;
  obraId?: string;
}

export function Relatorio({ obras, tipo, obraId }: RelatorioProps) {
  const obrasParaRelatorio = tipo === 'unitario' && obraId
    ? obras.filter(obra => obra.id === obraId)
    : obras;

  const valorTotal = obrasParaRelatorio.reduce((acc, obra) => acc + obra.valor, 0);
  const mediaProgresso = obrasParaRelatorio.reduce((acc, obra) => acc + obra.porcentagemConclusao, 0) / obrasParaRelatorio.length;

  return (
    <div className="bg-white p-6 rounded-lg shadow">
      <h2 className="text-xl font-bold mb-4">
        {tipo === 'unitario' ? 'Relatório Individual' : 'Relatório Global'}
      </h2>

      <div className="space-y-4">
        <div className="grid grid-cols-2 gap-4">
          <div>
            <p className="text-sm text-gray-600">Total de Obras:</p>
            <p className="font-medium">{obrasParaRelatorio.length}</p>
          </div>
          <div>
            <p className="text-sm text-gray-600">Valor Total:</p>
            <p className="font-medium">R$ {valorTotal.toLocaleString('pt-BR')}</p>
          </div>
          <div>
            <p className="text-sm text-gray-600">Progresso Médio:</p>
            <p className="font-medium">{mediaProgresso.toFixed(2)}%</p>
          </div>
        </div>

        <table className="min-w-full mt-4">
          <thead>
            <tr className="bg-gray-50">
              <th className="px-4 py-2 text-left">Obra</th>
              <th className="px-4 py-2 text-left">Valor</th>
              <th className="px-4 py-2 text-left">Progresso</th>
              <th className="px-4 py-2 text-left">Prazo Restante</th>
            </tr>
          </thead>
          <tbody>
            {obrasParaRelatorio.map((obra) => (
              <tr key={obra.id} className="border-t">
                <td className="px-4 py-2">{obra.nome}</td>
                <td className="px-4 py-2">R$ {obra.valor.toLocaleString('pt-BR')}</td>
                <td className="px-4 py-2">{obra.porcentagemConclusao}%</td>
                <td className="px-4 py-2">
                  {Math.ceil((obra.prazoVigenciaContrato.getTime() - new Date().getTime()) / (1000 * 60 * 60 * 24))} dias
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}