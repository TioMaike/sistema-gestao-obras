import React, { useState } from 'react';
import { AlertTriangle, FileText, Edit2, Check, X } from 'lucide-react';
import { Obra } from '../types/types';

interface ObraListProps {
  obras: Obra[];
  onGerarRelatorio: (id: string) => void;
  onUpdatePorcentagem: (id: string, novaPorcentagem: number) => void;
}

export function ObraList({ obras, onGerarRelatorio, onUpdatePorcentagem }: ObraListProps) {
  const [editingId, setEditingId] = useState<string | null>(null);
  const [tempPorcentagem, setTempPorcentagem] = useState<number>(0);

  const verificarPrazo = (data: Date) => {
    const hoje = new Date();
    const diasRestantes = Math.ceil((data.getTime() - hoje.getTime()) / (1000 * 60 * 60 * 24));
    return diasRestantes <= 30;
  };

  const handleEditClick = (obra: Obra) => {
    setEditingId(obra.id);
    setTempPorcentagem(obra.porcentagemConclusao);
  };

  const handleSave = (id: string) => {
    if (tempPorcentagem >= 0 && tempPorcentagem <= 100) {
      onUpdatePorcentagem(id, tempPorcentagem);
      setEditingId(null);
    }
  };

  const handleCancel = () => {
    setEditingId(null);
  };

  return (
    <div className="space-y-4">
      {obras.map((obra) => (
        <div key={obra.id} className="bg-white p-6 rounded-lg shadow">
          <div className="flex justify-between items-start">
            <div>
              <h3 className="text-lg font-semibold">{obra.nome}</h3>
              <p className="text-gray-600">Contrato: {obra.numeroContrato}</p>
            </div>
            {(verificarPrazo(obra.prazoExecucao) || verificarPrazo(obra.prazoVigenciaContrato)) && (
              <AlertTriangle className="text-yellow-500" />
            )}
          </div>

          <div className="mt-4 grid grid-cols-2 gap-4">
            <div>
              <p className="text-sm text-gray-600">Valor:</p>
              <p className="font-medium">R$ {obra.valor.toLocaleString('pt-BR')}</p>
            </div>
            <div>
              <p className="text-sm text-gray-600">Origem dos Recursos:</p>
              <p className="font-medium">{obra.origemRecursos}</p>
            </div>
            <div>
              <p className="text-sm text-gray-600">Processo Licitatório:</p>
              <p className="font-medium">{obra.numeroProcessoLicitatorio}</p>
            </div>
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Conclusão:</p>
                {editingId === obra.id ? (
                  <div className="flex items-center space-x-2">
                    <input
                      type="number"
                      min="0"
                      max="100"
                      value={tempPorcentagem}
                      onChange={(e) => setTempPorcentagem(Number(e.target.value))}
                      className="w-20 px-2 py-1 border rounded"
                    />
                    <button
                      onClick={() => handleSave(obra.id)}
                      className="text-green-600 hover:text-green-800"
                    >
                      <Check className="w-4 h-4" />
                    </button>
                    <button
                      onClick={handleCancel}
                      className="text-red-600 hover:text-red-800"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  </div>
                ) : (
                  <div className="flex items-center space-x-2">
                    <p className="font-medium">{obra.porcentagemConclusao}%</p>
                    <button
                      onClick={() => handleEditClick(obra)}
                      className="text-gray-600 hover:text-gray-800"
                    >
                      <Edit2 className="w-4 h-4" />
                    </button>
                  </div>
                )}
              </div>
            </div>
          </div>

          <div className="mt-4">
            <div className="w-full bg-gray-200 rounded-full h-2.5">
              <div
                className="bg-blue-600 h-2.5 rounded-full"
                style={{ width: `${obra.porcentagemConclusao}%` }}
              ></div>
            </div>
          </div>

          <button
            onClick={() => onGerarRelatorio(obra.id)}
            className="mt-4 flex items-center text-blue-600 hover:text-blue-800"
          >
            <FileText className="w-4 h-4 mr-1" />
            Gerar Relatório
          </button>
        </div>
      ))}
    </div>
  );
}