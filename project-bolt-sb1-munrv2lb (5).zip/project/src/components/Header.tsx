import React from 'react';
import { Building2, Download } from 'lucide-react';

export function Header() {
  const handleDownload = () => {
    // Substitua 'seu-usuario' pelo seu nome de usuário do GitHub
    window.open('https://github.com/seu-usuario/sistema-gestao-obras/releases/download/v1.0.0/Sistema-de-Gestao-de-Obras.exe', '_blank');
  };

  return (
    <header className="bg-blue-700 text-white p-4 shadow-lg">
      <div className="container mx-auto flex items-center justify-between">
        <div className="flex items-center">
          <Building2 className="w-8 h-8 mr-2" />
          <h1 className="text-2xl font-bold">Sistema de Gestão de Obras</h1>
        </div>
        <button
          onClick={handleDownload}
          className="flex items-center bg-white text-blue-700 px-4 py-2 rounded-md hover:bg-blue-50 transition-colors"
        >
          <Download className="w-5 h-5 mr-2" />
          Baixar Versão Desktop
        </button>
      </div>
    </header>
  );
}