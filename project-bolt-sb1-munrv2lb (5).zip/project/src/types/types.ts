export interface Obra {
  id: string;
  nome: string;
  valor: number;
  origemRecursos: string;
  numeroContrato: string;
  numeroProcessoLicitatorio: string;
  prazoExecucao: Date;
  prazoVigenciaContrato: Date;
  porcentagemConclusao: number;
  dataCriacao: Date;
  dataAtualizacao: Date;
}

export type RelatorioTipo = 'unitario' | 'global';