import React, { useState, useEffect } from 'react';
import { Header } from './components/Header';
import { ObraForm } from './components/ObraForm';
import { ObraList } from './components/ObraList';
import { Relatorio } from './components/Relatorio';
import { Obra, RelatorioTipo } from './types/types';
import { db } from './db/db';
import { useLiveQuery } from 'dexie-react-hooks';

function App() {
  const obras = useLiveQuery(() => db.obras.toArray()) || [];
  const [mostrarFormulario, setMostrarFormulario] = useState(false);
  const [relatorioTipo, setRelatorioTipo] = useState<RelatorioTipo | null>(null);
  const [relatorioObraId, setRelatorioObraId] = useState<string | undefined>();

  const handleSubmit = async (novaObra: Omit<Obra, 'id' | 'dataCriacao' | 'dataAtualizacao'>) => {
    const obra: Omit<Obra, 'id'> = {
      ...novaObra,
      dataCriacao: new Date(),
      dataAtualizacao: new Date()
    };
    await db.obras.add(obra);
    setMostrarFormulario(false);
  };

  const handleUpdatePorcentagem = async (id: string, novaPorcentagem: number) => {
    await db.obras.update(id, {
      porcentagemConclusao: novaPorcentagem,
      dataAtualizacao: new Date()
    });
  };

  const handleGerarRelatorio = (id: string) => {
    setRelatorioTipo('unitario');
    setRelatorioObraId(id);
  };

  return (
    <div className="min-h-screen bg-gray-100">
      <Header />
      
      <main className="container mx-auto px-4 py-8">
        <div className="flex justify-between items-center mb-6">
          <div className="space-x-2">
            <button
              onClick={() => setMostrarFormulario(!mostrarFormulario)}
              className="bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700"
            >
              {mostrarFormulario ? 'Cancelar' : 'Nova Obra'}
            </button>
            <button
              onClick={() => {
                setRelatorioTipo('global');
                setRelatorioObraId(undefined);
              }}
              className="bg-green-600 text-white px-4 py-2 rounded-md hover:bg-green-700"
            >
              Relatório Global
            </button>
          </div>
        </div>

        {mostrarFormulario && (
          <div className="mb-8">
            <ObraForm onSubmit={handleSubmit} />
          </div>
        )}

        {relatorioTipo && (
          <div className="mb-8">
            <Relatorio
              obras={obras}
              tipo={relatorioTipo}
              obraId={relatorioObraId}
            />
            <button
              onClick={() => {
                setRelatorioTipo(null);
                setRelatorioObraId(undefined);
              }}
              className="mt-4 text-gray-600 hover:text-gray-800"
            >
              Fechar Relatório
            </button>
          </div>
        )}

        <ObraList 
          obras={obras} 
          onGerarRelatorio={handleGerarRelatorio} 
          onUpdatePorcentagem={handleUpdatePorcentagem}
        />
      </main>
    </div>
  );
}

export default App