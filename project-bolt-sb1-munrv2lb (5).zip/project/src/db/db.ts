import Dexie, { Table } from 'dexie';
import { Obra } from '../types/types';

export class ObrasDatabase extends Dexie {
  obras!: Table<Obra>;

  constructor() {
    super('ObrasDB');
    this.version(1).stores({
      obras: '++id, nome, valor, origemRecursos, numeroContrato, numeroProcessoLicitatorio, prazoExecucao, prazoVigenciaContrato, porcentagemConclusao, dataCriacao, dataAtualizacao'
    });
  }
}

export const db = new ObrasDatabase();